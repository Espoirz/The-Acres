import React from 'react';
import { Switch, Route } from 'react-router-dom';
import LoginPage from './pages/LoginPage';
import Dashboard from './pages/Dashboard';

function App() {
  return (
    <div className="App min-h-screen bg-gray-100">
      <Switch>
        <Route path="/login" component={LoginPage} />
        <Route path="/dashboard" component={Dashboard} />
        <Route path="/" exact component={LoginPage} />
      </Switch>
    </div>
  );
}

export default App;
import React, { useState, useEffect } from 'react';
import { Route, Switch, useHistory } from 'react-router-dom';
import Navbar from './components/Navbar';
import Dashboard from './pages/Dashboard';
import LoginPage from './pages/LoginPage';
import ClubPage from './pages/ClubPage';
import AnimalList from './components/AnimalList';
import BreedingPanel from './components/BreedingPanel';
import VeterinaryCenter from './components/VeterinaryCenter';
import WildernessExplorer from './components/WildernessExplorer';
import ForumBoard from './components/ForumBoard';
import ChatSystem from './components/ChatSystem';

function App() {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [user, setUser] = useState(null);
  const history = useHistory();

  useEffect(() => {
    const token = localStorage.getItem('token');
    if (token) {
      setIsAuthenticated(true);
      // Verify token and get user data
    }
  }, []);

  const handleLogin = (userData: any) => {
    setIsAuthenticated(true);
    setUser(userData);
    history.push('/dashboard');
  };

  const handleLogout = () => {
    localStorage.removeItem('token');
    setIsAuthenticated(false);
    setUser(null);
    history.push('/login');
  };

  return (
    <div className="min-h-screen bg-gray-100">
      {isAuthenticated && <Navbar onLogout={handleLogout} />}
      
      <Switch>
        <Route path="/login">
          <LoginPage onLogin={handleLogin} />
        </Route>
        
        {isAuthenticated ? (
          <>
            <Route path="/dashboard">
              <Dashboard />
            </Route>
            <Route path="/animals">
              <AnimalList />
            </Route>
            <Route path="/breeding">
              <BreedingPanel />
            </Route>
            <Route path="/veterinary">
              <VeterinaryCenter />
            </Route>
            <Route path="/wilderness">
              <WildernessExplorer />
            </Route>
            <Route path="/forum">
              <ForumBoard />
            </Route>
            <Route path="/chat">
              <ChatSystem />
            </Route>
            <Route path="/clubs">
              <ClubPage />
            </Route>
            <Route path="/">
              <Dashboard />
            </Route>
          </>
        ) : (
          <Route path="/">
            <LoginPage onLogin={handleLogin} />
          </Route>
        )}
      </Switch>
    </div>
  );
}

export default App;
