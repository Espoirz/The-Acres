
import React, { useState, useEffect, useRef } from 'react';
import axios from 'axios';
import io from 'socket.io-client';

interface ChatMessage {
  id: string;
  content: string;
  sender: { id: string; username: string };
  timestamp: Date;
  channel: string;
}

export default function ChatSystem() {
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [newMessage, setNewMessage] = useState('');
  const [currentChannel, setCurrentChannel] = useState('global');
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const socketRef = useRef<any>(null);

  useEffect(() => {
    fetchMessages();
    
    // Initialize socket connection
    socketRef.current = io('http://localhost:4000');
    
    socketRef.current.on('new_message', (message: ChatMessage) => {
      if (message.channel === currentChannel) {
        setMessages(prev => [...prev, message]);
      }
    });

    return () => {
      if (socketRef.current) {
        socketRef.current.disconnect();
      }
    };
  }, [currentChannel]);

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  const fetchMessages = async () => {
    try {
      const token = localStorage.getItem('token');
      const response = await axios.get(`/api/chat/messages?channel=${currentChannel}`, {
        headers: { Authorization: `Bearer ${token}` }
      });
      setMessages(response.data);
    } catch (error) {
      console.error('Failed to fetch messages:', error);
    }
  };

  const sendMessage = async () => {
    if (!newMessage.trim()) return;

    try {
      const token = localStorage.getItem('token');
      await axios.post('/api/chat/messages', 
        { content: newMessage, channel: currentChannel },
        { headers: { Authorization: `Bearer ${token}` } }
      );
      setNewMessage('');
    } catch (error) {
      console.error('Failed to send message:', error);
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      sendMessage();
    }
  };

  return (
    <div className="flex flex-col h-96 bg-white rounded-lg shadow-md">
      <div className="bg-gray-100 p-3 rounded-t-lg border-b">
        <div className="flex space-x-2">
          <button 
            onClick={() => setCurrentChannel('global')}
            className={`px-3 py-1 rounded ${currentChannel === 'global' ? 'bg-blue-500 text-white' : 'bg-gray-200'}`}
          >
            Global
          </button>
          <button 
            onClick={() => setCurrentChannel('club')}
            className={`px-3 py-1 rounded ${currentChannel === 'club' ? 'bg-blue-500 text-white' : 'bg-gray-200'}`}
          >
            Club
          </button>
        </div>
      </div>

      <div className="flex-1 overflow-y-auto p-3 space-y-2">
        {messages.map(message => (
          <div key={message.id} className="flex flex-col">
            <div className="flex items-baseline space-x-2">
              <span className="font-semibold text-sm text-blue-600">
                {message.sender.username}
              </span>
              <span className="text-xs text-gray-500">
                {new Date(message.timestamp).toLocaleTimeString()}
              </span>
            </div>
            <p className="text-sm">{message.content}</p>
          </div>
        ))}
        <div ref={messagesEndRef} />
      </div>

      <div className="p-3 border-t">
        <div className="flex space-x-2">
          <input
            type="text"
            value={newMessage}
            onChange={(e) => setNewMessage(e.target.value)}
            onKeyPress={handleKeyPress}
            placeholder="Type your message..."
            className="flex-1 p-2 border rounded"
          />
          <button 
            onClick={sendMessage}
            className="bg-blue-500 text-white px-4 py-2 rounded hover:bg-blue-600"
          >
            Send
          </button>
        </div>
      </div>
    </div>
  );
}
