
import React, { useState, useEffect } from 'react';
import axios from 'axios';

interface Animal {
  id: string;
  name: string;
  breed: string;
  stage: string;
  ageMonths: number;
}

interface VetRecord {
  id: string;
  description: string;
  date: Date;
  animal: Animal;
}

export default function VeterinaryCenter() {
  const [animals, setAnimals] = useState<Animal[]>([]);
  const [selectedAnimal, setSelectedAnimal] = useState('');
  const [vetRecords, setVetRecords] = useState<VetRecord[]>([]);
  const [description, setDescription] = useState('');

  useEffect(() => {
    fetchAnimals();
  }, []);

  useEffect(() => {
    if (selectedAnimal) {
      fetchVetRecords(selectedAnimal);
    }
  }, [selectedAnimal]);

  const fetchAnimals = async () => {
    try {
      const token = localStorage.getItem('token');
      const response = await axios.get('/api/animals', {
        headers: { Authorization: `Bearer ${token}` }
      });
      setAnimals(response.data);
    } catch (error) {
      console.error('Failed to fetch animals:', error);
    }
  };

  const fetchVetRecords = async (animalId: string) => {
    try {
      const token = localStorage.getItem('token');
      const response = await axios.get(`/api/veterinary/records/${animalId}`, {
        headers: { Authorization: `Bearer ${token}` }
      });
      setVetRecords(response.data);
    } catch (error) {
      console.error('Failed to fetch vet records:', error);
    }
  };

  const addVetRecord = async () => {
    if (!selectedAnimal || !description) {
      alert('Please select an animal and enter a description');
      return;
    }

    try {
      const token = localStorage.getItem('token');
      await axios.post('/api/veterinary/records', 
        { animalId: selectedAnimal, description },
        { headers: { Authorization: `Bearer ${token}` } }
      );
      setDescription('');
      fetchVetRecords(selectedAnimal);
      alert('Veterinary record added successfully');
    } catch (error) {
      console.error('Failed to add vet record:', error);
      alert('Failed to add veterinary record');
    }
  };

  const scheduleCheckup = async () => {
    if (!selectedAnimal) {
      alert('Please select an animal');
      return;
    }

    try {
      const token = localStorage.getItem('token');
      await axios.post('/api/veterinary/checkup', 
        { animalId: selectedAnimal },
        { headers: { Authorization: `Bearer ${token}` } }
      );
      fetchVetRecords(selectedAnimal);
      alert('Routine checkup scheduled successfully');
    } catch (error) {
      console.error('Failed to schedule checkup:', error);
      alert('Failed to schedule checkup');
    }
  };

  return (
    <div className="p-6 bg-white rounded-lg shadow-md">
      <h2 className="text-2xl font-bold mb-4">Veterinary Center</h2>
      
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div>
          <div className="mb-4">
            <label className="block text-sm font-medium mb-2">Select Animal</label>
            <select 
              value={selectedAnimal} 
              onChange={(e) => setSelectedAnimal(e.target.value)}
              className="w-full p-2 border rounded"
            >
              <option value="">Choose an animal...</option>
              {animals.map(animal => (
                <option key={animal.id} value={animal.id}>
                  {animal.name} ({animal.breed}) - {animal.stage}
                </option>
              ))}
            </select>
          </div>

          <div className="mb-4">
            <label className="block text-sm font-medium mb-2">Treatment/Notes</label>
            <textarea
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="Enter treatment details or health notes..."
              className="w-full p-2 border rounded h-24"
            />
          </div>

          <div className="flex space-x-2">
            <button 
              onClick={addVetRecord}
              className="bg-blue-500 text-white px-4 py-2 rounded hover:bg-blue-600"
            >
              Add Record
            </button>
            <button 
              onClick={scheduleCheckup}
              className="bg-green-500 text-white px-4 py-2 rounded hover:bg-green-600"
            >
              Schedule Checkup
            </button>
          </div>
        </div>

        <div>
          <h3 className="text-lg font-semibold mb-3">Medical History</h3>
          {selectedAnimal ? (
            <div className="space-y-3 max-h-64 overflow-y-auto">
              {vetRecords.map(record => (
                <div key={record.id} className="p-3 bg-gray-50 rounded">
                  <p className="text-sm text-gray-600 mb-1">
                    {new Date(record.date).toLocaleDateString()}
                  </p>
                  <p>{record.description}</p>
                </div>
              ))}
              {vetRecords.length === 0 && (
                <p className="text-gray-500">No medical records found for this animal.</p>
              )}
            </div>
          ) : (
            <p className="text-gray-500">Select an animal to view medical history.</p>
          )}
        </div>
      </div>
    </div>
  );
}
