
import React, { useState, useEffect } from 'react';
import axios from 'axios';

interface ForumPost {
  id: string;
  title: string;
  content: string;
  author: { id: string; username: string };
  createdAt: Date;
  replies: ForumPost[];
}

export default function ForumBoard() {
  const [posts, setPosts] = useState<ForumPost[]>([]);
  const [newPostTitle, setNewPostTitle] = useState('');
  const [newPostContent, setNewPostContent] = useState('');
  const [showNewPostForm, setShowNewPostForm] = useState(false);
  const [selectedPost, setSelectedPost] = useState<ForumPost | null>(null);
  const [replyContent, setReplyContent] = useState('');

  useEffect(() => {
    fetchPosts();
  }, []);

  const fetchPosts = async () => {
    try {
      const token = localStorage.getItem('token');
      const response = await axios.get('/api/forum/posts', {
        headers: { Authorization: `Bearer ${token}` }
      });
      setPosts(response.data);
    } catch (error) {
      console.error('Failed to fetch posts:', error);
    }
  };

  const createPost = async () => {
    if (!newPostTitle || !newPostContent) {
      alert('Please enter both title and content');
      return;
    }

    try {
      const token = localStorage.getItem('token');
      await axios.post('/api/forum/posts', 
        { title: newPostTitle, content: newPostContent },
        { headers: { Authorization: `Bearer ${token}` } }
      );
      setNewPostTitle('');
      setNewPostContent('');
      setShowNewPostForm(false);
      fetchPosts();
    } catch (error) {
      console.error('Failed to create post:', error);
      alert('Failed to create post');
    }
  };

  const addReply = async (parentPostId: string) => {
    if (!replyContent) {
      alert('Please enter reply content');
      return;
    }

    try {
      const token = localStorage.getItem('token');
      await axios.post('/api/forum/posts', 
        { title: 'Reply', content: replyContent, parentPostId },
        { headers: { Authorization: `Bearer ${token}` } }
      );
      setReplyContent('');
      fetchPosts();
    } catch (error) {
      console.error('Failed to add reply:', error);
      alert('Failed to add reply');
    }
  };

  return (
    <div className="p-6 bg-white rounded-lg shadow-md">
      <div className="flex justify-between items-center mb-4">
        <h2 className="text-2xl font-bold">Community Forum</h2>
        <button 
          onClick={() => setShowNewPostForm(!showNewPostForm)}
          className="bg-blue-500 text-white px-4 py-2 rounded hover:bg-blue-600"
        >
          New Post
        </button>
      </div>

      {showNewPostForm && (
        <div className="mb-6 p-4 bg-gray-50 rounded">
          <div className="mb-3">
            <input
              type="text"
              placeholder="Post title..."
              value={newPostTitle}
              onChange={(e) => setNewPostTitle(e.target.value)}
              className="w-full p-2 border rounded"
            />
          </div>
          <div className="mb-3">
            <textarea
              placeholder="Post content..."
              value={newPostContent}
              onChange={(e) => setNewPostContent(e.target.value)}
              className="w-full p-2 border rounded h-24"
            />
          </div>
          <div className="flex space-x-2">
            <button 
              onClick={createPost}
              className="bg-green-500 text-white px-4 py-2 rounded hover:bg-green-600"
            >
              Create Post
            </button>
            <button 
              onClick={() => setShowNewPostForm(false)}
              className="bg-gray-500 text-white px-4 py-2 rounded hover:bg-gray-600"
            >
              Cancel
            </button>
          </div>
        </div>
      )}

      <div className="space-y-4">
        {posts.map(post => (
          <div key={post.id} className="border rounded p-4">
            <div className="flex justify-between items-start mb-2">
              <h3 className="text-lg font-semibold">{post.title}</h3>
              <span className="text-sm text-gray-500">
                by {post.author.username} on {new Date(post.createdAt).toLocaleDateString()}
              </span>
            </div>
            <p className="text-gray-700 mb-3">{post.content}</p>
            
            {post.replies && post.replies.length > 0 && (
              <div className="ml-4 border-l-2 border-gray-200 pl-4">
                <h4 className="font-medium mb-2">Replies ({post.replies.length})</h4>
                {post.replies.map(reply => (
                  <div key={reply.id} className="mb-2 p-2 bg-gray-50 rounded">
                    <div className="flex justify-between items-center mb-1">
                      <span className="font-medium text-sm">{reply.author.username}</span>
                      <span className="text-xs text-gray-500">
                        {new Date(reply.createdAt).toLocaleDateString()}
                      </span>
                    </div>
                    <p className="text-sm">{reply.content}</p>
                  </div>
                ))}
              </div>
            )}

            <div className="mt-3 pt-3 border-t">
              <div className="flex space-x-2">
                <input
                  type="text"
                  placeholder="Write a reply..."
                  value={selectedPost?.id === post.id ? replyContent : ''}
                  onChange={(e) => {
                    setSelectedPost(post);
                    setReplyContent(e.target.value);
                  }}
                  className="flex-1 p-2 border rounded text-sm"
                />
                <button 
                  onClick={() => addReply(post.id)}
                  className="bg-blue-500 text-white px-3 py-2 rounded text-sm hover:bg-blue-600"
                >
                  Reply
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
