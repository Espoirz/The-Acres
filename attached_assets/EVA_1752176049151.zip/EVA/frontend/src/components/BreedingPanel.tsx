
import React, { useState, useEffect } from 'react';
import axios from 'axios';

interface Animal {
  id: string;
  name: string;
  breed: string;
  species: 'horse' | 'dog';
  genetics: any;
}

export default function BreedingPanel() {
  const [animals, setAnimals] = useState<Animal[]>([]);
  const [selectedSire, setSelectedSire] = useState('');
  const [selectedDam, setSelectedDam] = useState('');
  const [breedingHistory, setBreedingHistory] = useState([]);

  useEffect(() => {
    fetchAnimals();
    fetchBreedingHistory();
  }, []);

  const fetchAnimals = async () => {
    try {
      const token = localStorage.getItem('token');
      const response = await axios.get('/api/animals', {
        headers: { Authorization: `Bearer ${token}` }
      });
      setAnimals(response.data);
    } catch (error) {
      console.error('Failed to fetch animals:', error);
    }
  };

  const fetchBreedingHistory = async () => {
    try {
      const token = localStorage.getItem('token');
      const response = await axios.get('/api/breeding/history', {
        headers: { Authorization: `Bearer ${token}` }
      });
      setBreedingHistory(response.data);
    } catch (error) {
      console.error('Failed to fetch breeding history:', error);
    }
  };

  const handleBreeding = async () => {
    if (!selectedSire || !selectedDam) {
      alert('Please select both sire and dam');
      return;
    }

    try {
      const token = localStorage.getItem('token');
      await axios.post('/api/breeding/breed', 
        { sireId: selectedSire, damId: selectedDam },
        { headers: { Authorization: `Bearer ${token}` } }
      );
      alert('Breeding successful! Check your animals list for the new foal.');
      fetchAnimals();
      fetchBreedingHistory();
      setSelectedSire('');
      setSelectedDam('');
    } catch (error) {
      console.error('Breeding failed:', error);
      alert('Breeding failed. Please try again.');
    }
  };

  return (
    <div className="p-6 bg-white rounded-lg shadow-md">
      <h2 className="text-2xl font-bold mb-4">Breeding Center</h2>
      
      <div className="grid grid-cols-2 gap-4 mb-6">
        <div>
          <label className="block text-sm font-medium mb-2">Select Sire</label>
          <select 
            value={selectedSire} 
            onChange={(e) => setSelectedSire(e.target.value)}
            className="w-full p-2 border rounded"
          >
            <option value="">Choose a sire...</option>
            {animals.filter(a => a.species === 'horse').map(animal => (
              <option key={animal.id} value={animal.id}>
                {animal.name} ({animal.breed})
              </option>
            ))}
          </select>
        </div>
        
        <div>
          <label className="block text-sm font-medium mb-2">Select Dam</label>
          <select 
            value={selectedDam} 
            onChange={(e) => setSelectedDam(e.target.value)}
            className="w-full p-2 border rounded"
          >
            <option value="">Choose a dam...</option>
            {animals.filter(a => a.species === 'horse').map(animal => (
              <option key={animal.id} value={animal.id}>
                {animal.name} ({animal.breed})
              </option>
            ))}
          </select>
        </div>
      </div>

      <button 
        onClick={handleBreeding}
        className="bg-blue-500 text-white px-6 py-2 rounded hover:bg-blue-600"
      >
        Breed Animals
      </button>

      <div className="mt-8">
        <h3 className="text-lg font-semibold mb-4">Breeding History</h3>
        <div className="space-y-2">
          {breedingHistory.map((log: any) => (
            <div key={log.id} className="p-3 bg-gray-100 rounded">
              <p><strong>Sire:</strong> {log.sire?.name}</p>
              <p><strong>Dam:</strong> {log.dam?.name}</p>
              <p><strong>Date:</strong> {new Date(log.date).toLocaleDateString()}</p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
