
import React, { useState, useEffect } from 'react';
import axios from 'axios';

interface WildernessArea {
  id: string;
  name: string;
  description: string;
  difficulty: number;
  requirements: {
    minLevel: number;
    requiredItems?: string[];
  };
}

export default function WildernessExplorer() {
  const [areas, setAreas] = useState<WildernessArea[]>([]);
  const [selectedArea, setSelectedArea] = useState<WildernessArea | null>(null);
  const [exploring, setExploring] = useState(false);
  const [lastEncounter, setLastEncounter] = useState<any>(null);

  useEffect(() => {
    fetchAreas();
  }, []);

  const fetchAreas = async () => {
    try {
      const token = localStorage.getItem('token');
      const response = await axios.get('/api/wilderness/areas', {
        headers: { Authorization: `Bearer ${token}` }
      });
      setAreas(response.data);
    } catch (error) {
      console.error('Failed to fetch wilderness areas:', error);
    }
  };

  const exploreArea = async (areaId: string) => {
    setExploring(true);
    try {
      const token = localStorage.getItem('token');
      const response = await axios.post(`/api/wilderness/explore/${areaId}`, {}, {
        headers: { Authorization: `Bearer ${token}` }
      });
      setLastEncounter(response.data);
    } catch (error) {
      console.error('Exploration failed:', error);
    } finally {
      setExploring(false);
    }
  };

  return (
    <div className="p-6 bg-white rounded-lg shadow-md">
      <h2 className="text-2xl font-bold mb-4">Wilderness Explorer</h2>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div>
          <h3 className="text-lg font-semibold mb-3">Available Areas</h3>
          <div className="space-y-3">
            {areas.map(area => (
              <div 
                key={area.id} 
                className={`p-4 border rounded cursor-pointer hover:bg-gray-50 ${
                  selectedArea?.id === area.id ? 'border-blue-500 bg-blue-50' : ''
                }`}
                onClick={() => setSelectedArea(area)}
              >
                <h4 className="font-medium">{area.name}</h4>
                <p className="text-sm text-gray-600">{area.description}</p>
                <div className="flex items-center mt-2">
                  <span className="text-xs bg-yellow-100 text-yellow-800 px-2 py-1 rounded">
                    Difficulty: {area.difficulty}/10
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>

        <div>
          {selectedArea && (
            <div className="space-y-4">
              <div className="p-4 bg-gray-50 rounded">
                <h3 className="text-lg font-semibold">{selectedArea.name}</h3>
                <p className="text-gray-600 mb-3">{selectedArea.description}</p>
                <div className="space-y-2">
                  <p><strong>Difficulty:</strong> {selectedArea.difficulty}/10</p>
                  <p><strong>Min Level:</strong> {selectedArea.requirements.minLevel}</p>
                  {selectedArea.requirements.requiredItems && (
                    <p><strong>Required Items:</strong> {selectedArea.requirements.requiredItems.join(', ')}</p>
                  )}
                </div>
                <button 
                  onClick={() => exploreArea(selectedArea.id)}
                  disabled={exploring}
                  className="mt-4 bg-green-500 text-white px-4 py-2 rounded hover:bg-green-600 disabled:bg-gray-400"
                >
                  {exploring ? 'Exploring...' : 'Explore Area'}
                </button>
              </div>

              {lastEncounter && (
                <div className="p-4 bg-blue-50 rounded">
                  <h4 className="font-semibold mb-2">Last Encounter</h4>
                  {lastEncounter.encounter ? (
                    <div>
                      <p><strong>Outcome:</strong> {lastEncounter.encounter.outcome}</p>
                      <p><strong>Experience:</strong> +{lastEncounter.encounter.rewards.experience}</p>
                      <p><strong>Currency:</strong> +{lastEncounter.encounter.rewards.currency}</p>
                      {lastEncounter.animal && (
                        <p className="text-green-600 font-medium">
                          You captured: {lastEncounter.animal.name}!
                        </p>
                      )}
                    </div>
                  ) : (
                    <p>{lastEncounter.message}</p>
                  )}
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
