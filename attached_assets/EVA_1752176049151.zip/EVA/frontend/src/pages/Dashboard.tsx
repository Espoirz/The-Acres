import React, { useState } from 'react';
import AnimalList from '../components/AnimalList';
import BreedingPanel from '../components/BreedingPanel';
import VeterinaryCenter from '../components/VeterinaryCenter';
import WildernessExplorer from '../components/WildernessExplorer';
import ForumBoard from '../components/ForumBoard';
import ChatSystem from '../components/ChatSystem';

export default function Dashboard() {
  const [activeTab, setActiveTab] = useState('animals');

  const tabs = [
    { id: 'animals', label: 'My Animals', component: <AnimalList /> },
    { id: 'breeding', label: 'Breeding', component: <BreedingPanel /> },
    { id: 'veterinary', label: 'Veterinary', component: <VeterinaryCenter /> },
    { id: 'wilderness', label: 'Wilderness', component: <WildernessExplorer /> },
    { id: 'forum', label: 'Forum', component: <ForumBoard /> },
    { id: 'chat', label: 'Chat', component: <ChatSystem /> }
  ];

  return (
    <div className="p-4">
      <h1 className="text-3xl font-bold mb-6">Everlasting Victory Acres</h1>
      
      <div className="mb-6">
        <div className="flex space-x-1 bg-gray-100 p-1 rounded-lg">
          {tabs.map(tab => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`px-4 py-2 rounded-md transition-colors ${
                activeTab === tab.id 
                  ? 'bg-white text-blue-600 shadow-sm' 
                  : 'text-gray-600 hover:text-gray-900'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>
      </div>

      <div className="min-h-screen">
        {tabs.find(tab => tab.id === activeTab)?.component}
      </div>
    </div>
  );
}
