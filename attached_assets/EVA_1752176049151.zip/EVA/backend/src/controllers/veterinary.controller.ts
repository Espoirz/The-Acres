
import { Request, Response } from 'express';
import { AppDataSource } from '../ormconfig';
import { VetRecord } from '../entities/VetRecord';
import { Animal } from '../entities/Animal';

export const addVetRecord = async (req: Request, res: Response) => {
  try {
    const { animalId, description, treatment } = req.body;
    const vetRepo = AppDataSource.getRepository(VetRecord);
    const animalRepo = AppDataSource.getRepository(Animal);

    const animal = await animalRepo.findOne({ where: { id: animalId } });
    if (!animal) {
      return res.status(404).json({ error: 'Animal not found' });
    }

    const vetRecord = new VetRecord();
    vetRecord.animal = animal;
    vetRecord.description = description;

    await vetRepo.save(vetRecord);
    res.json(vetRecord);
  } catch (error) {
    res.status(500).json({ error: 'Failed to add veterinary record' });
  }
};

export const getVetRecords = async (req: Request, res: Response) => {
  try {
    const { animalId } = req.params;
    const vetRepo = AppDataSource.getRepository(VetRecord);
    
    const records = await vetRepo.find({
      where: { animal: { id: animalId } },
      relations: ['animal'],
      order: { date: 'DESC' }
    });

    res.json(records);
  } catch (error) {
    res.status(500).json({ error: 'Failed to fetch veterinary records' });
  }
};

export const scheduleCheckup = async (req: Request, res: Response) => {
  try {
    const { animalId } = req.body;
    const animalRepo = AppDataSource.getRepository(Animal);
    const vetRepo = AppDataSource.getRepository(VetRecord);

    const animal = await animalRepo.findOne({ where: { id: animalId } });
    if (!animal) {
      return res.status(404).json({ error: 'Animal not found' });
    }

    const checkup = new VetRecord();
    checkup.animal = animal;
    checkup.description = `Routine health checkup - ${animal.stage} stage assessment`;

    await vetRepo.save(checkup);
    res.json({ message: 'Checkup scheduled successfully', checkup });
  } catch (error) {
    res.status(500).json({ error: 'Failed to schedule checkup' });
  }
};
