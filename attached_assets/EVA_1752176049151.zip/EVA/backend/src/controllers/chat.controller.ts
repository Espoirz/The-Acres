
import { Request, Response } from 'express';
import { AppDataSource } from '../ormconfig';
import { ChatMessage } from '../entities/ChatMessage';

export const sendMessage = async (req: Request, res: Response) => {
  try {
    const { content, channel, targetId } = req.body;
    const chatRepo = AppDataSource.getRepository(ChatMessage);

    const message = new ChatMessage();
    message.sender = (req as any).user;
    message.content = content;
    message.channel = channel || 'global';
    if (targetId) message.targetId = targetId;

    await chatRepo.save(message);
    
    // Emit to socket for real-time chat
    const io = (req as any).io;
    if (io) {
      io.emit('new_message', { ...message, sender: { id: message.sender.id, username: message.sender.username } });
    }

    res.json(message);
  } catch (error) {
    res.status(500).json({ error: 'Failed to send message' });
  }
};

export const getMessages = async (req: Request, res: Response) => {
  try {
    const { channel, targetId } = req.query;
    const chatRepo = AppDataSource.getRepository(ChatMessage);

    const whereClause: any = { channel: channel || 'global' };
    if (targetId) whereClause.targetId = targetId;

    const messages = await chatRepo.find({
      where: whereClause,
      relations: ['sender'],
      order: { timestamp: 'DESC' },
      take: 50
    });

    res.json(messages.reverse());
  } catch (error) {
    res.status(500).json({ error: 'Failed to fetch messages' });
  }
};
