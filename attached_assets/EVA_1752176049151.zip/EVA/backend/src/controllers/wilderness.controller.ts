
import { Request, Response } from 'express';
import { AppDataSource } from '../ormconfig';
import { WildernessArea } from '../entities/WildernessArea';
import { WildernessEncounter } from '../entities/WildernessEncounter';
import { Animal } from '../entities/Animal';

export const getWildernessAreas = async (req: Request, res: Response) => {
  try {
    const areaRepo = AppDataSource.getRepository(WildernessArea);
    const areas = await areaRepo.find();
    res.json(areas);
  } catch (error) {
    res.status(500).json({ error: 'Failed to fetch wilderness areas' });
  }
};

export const exploreArea = async (req: Request, res: Response) => {
  try {
    const { areaId } = req.params;
    const areaRepo = AppDataSource.getRepository(WildernessArea);
    const encounterRepo = AppDataSource.getRepository(WildernessEncounter);
    const animalRepo = AppDataSource.getRepository(Animal);

    const area = await areaRepo.findOne({ where: { id: areaId } });
    if (!area) {
      return res.status(404).json({ error: 'Wilderness area not found' });
    }

    // Simulate random encounter
    const encounterChance = Math.random();
    let outcome: 'captured' | 'escaped' | 'befriended' | 'injured';
    let rewards = { experience: 10, currency: 5 };

    if (encounterChance > 0.7) {
      // Create a wild animal encounter
      const wildAnimal = new Animal();
      wildAnimal.name = `Wild ${['Mustang', 'Wolf', 'Bear', 'Eagle'][Math.floor(Math.random() * 4)]}`;
      wildAnimal.species = Math.random() > 0.5 ? 'horse' : 'dog';
      wildAnimal.breed = 'Wild';
      wildAnimal.stage = 'Adult';
      wildAnimal.ageMonths = Math.floor(Math.random() * 60) + 24;

      const captureSuccess = Math.random() > 0.5;
      outcome = captureSuccess ? 'captured' : 'escaped';

      if (captureSuccess) {
        wildAnimal.owner = (req as any).user;
        await animalRepo.save(wildAnimal);
        rewards = { experience: 50, currency: 25 };
      }

      const encounter = new WildernessEncounter();
      encounter.player = (req as any).user;
      encounter.animal = wildAnimal;
      encounter.area = area;
      encounter.outcome = outcome;
      encounter.rewards = rewards;

      await encounterRepo.save(encounter);
      res.json({ encounter, animal: captureSuccess ? wildAnimal : null });
    } else {
      res.json({ message: 'No encounters found this time', rewards });
    }
  } catch (error) {
    res.status(500).json({ error: 'Exploration failed' });
  }
};
