
import { Request, Response } from 'express';
import { AppDataSource } from '../ormconfig';
import { Animal } from '../entities/Animal';
import { BreedingLog } from '../entities/BreedingLog';
import { GeneticProfile } from '../entities/GeneticProfile';

export const breedAnimals = async (req: Request, res: Response) => {
  try {
    const { sireId, damId } = req.body;
    const animalRepo = AppDataSource.getRepository(Animal);
    const breedingRepo = AppDataSource.getRepository(BreedingLog);
    const geneticsRepo = AppDataSource.getRepository(GeneticProfile);

    const sire = await animalRepo.findOne({ where: { id: sireId }, relations: ['genetics'] });
    const dam = await animalRepo.findOne({ where: { id: damId }, relations: ['genetics'] });

    if (!sire || !dam) {
      return res.status(404).json({ error: 'Parent animals not found' });
    }

    // Generate offspring genetics
    const offspring = new Animal();
    offspring.name = `${sire.name} x ${dam.name} Foal`;
    offspring.species = sire.species;
    offspring.breed = Math.random() > 0.5 ? sire.breed : dam.breed;
    offspring.stage = 'Foal';
    offspring.ageMonths = 0;
    offspring.owner = (req as any).user;

    // Create genetics profile for offspring
    const offspringGenetics = new GeneticProfile();
    offspringGenetics.traits = {
      speed: Math.floor((sire.genetics.traits.speed + dam.genetics.traits.speed) / 2 + (Math.random() - 0.5) * 20),
      stamina: Math.floor((sire.genetics.traits.stamina + dam.genetics.traits.stamina) / 2 + (Math.random() - 0.5) * 20),
      strength: Math.floor((sire.genetics.traits.strength + dam.genetics.traits.strength) / 2 + (Math.random() - 0.5) * 20),
      intelligence: Math.floor((sire.genetics.traits.intelligence + dam.genetics.traits.intelligence) / 2 + (Math.random() - 0.5) * 20),
      coat_color: Math.random() > 0.5 ? sire.genetics.traits.coat_color : dam.genetics.traits.coat_color,
      markings: [...sire.genetics.traits.markings, ...dam.genetics.traits.markings].slice(0, 3)
    };

    await geneticsRepo.save(offspringGenetics);
    offspring.genetics = offspringGenetics;
    const savedOffspring = await animalRepo.save(offspring);

    // Log the breeding
    const breedingLog = new BreedingLog();
    breedingLog.sire = sire;
    breedingLog.dam = dam;
    breedingLog.resultFoalId = savedOffspring.id;
    await breedingRepo.save(breedingLog);

    res.json(savedOffspring);
  } catch (error) {
    res.status(500).json({ error: 'Breeding failed' });
  }
};

export const getBreedingHistory = async (req: Request, res: Response) => {
  try {
    const breedingRepo = AppDataSource.getRepository(BreedingLog);
    const history = await breedingRepo.find({
      relations: ['sire', 'dam'],
      order: { date: 'DESC' }
    });
    res.json(history);
  } catch (error) {
    res.status(500).json({ error: 'Failed to fetch breeding history' });
  }
};
