
import { Request, Response } from 'express';
import { AppDataSource } from '../ormconfig';
import { ForumPost } from '../entities/ForumPost';
import { Club } from '../entities/Club';

export const createPost = async (req: Request, res: Response) => {
  try {
    const { title, content, clubId, parentPostId } = req.body;
    const postRepo = AppDataSource.getRepository(ForumPost);
    const clubRepo = AppDataSource.getRepository(Club);

    const post = new ForumPost();
    post.title = title;
    post.content = content;
    post.author = (req as any).user;

    if (clubId) {
      const club = await clubRepo.findOne({ where: { id: clubId } });
      if (club) post.club = club;
    }

    if (parentPostId) {
      const parentPost = await postRepo.findOne({ where: { id: parentPostId } });
      if (parentPost) post.parentPost = parentPost;
    }

    await postRepo.save(post);
    res.json(post);
  } catch (error) {
    res.status(500).json({ error: 'Failed to create post' });
  }
};

export const getPosts = async (req: Request, res: Response) => {
  try {
    const { clubId } = req.query;
    const postRepo = AppDataSource.getRepository(ForumPost);

    const whereClause = clubId ? { club: { id: clubId as string } } : {};
    
    const posts = await postRepo.find({
      where: { ...whereClause, parentPost: null },
      relations: ['author', 'club', 'replies', 'replies.author'],
      order: { createdAt: 'DESC' }
    });

    res.json(posts);
  } catch (error) {
    res.status(500).json({ error: 'Failed to fetch posts' });
  }
};
