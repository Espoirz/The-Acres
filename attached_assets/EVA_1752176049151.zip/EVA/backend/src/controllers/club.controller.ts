
import { Request, Response } from 'express';
import { getRepository } from 'typeorm';
import { Club } from '../entities/Club';

export const listClubs = async (req: Request, res: Response) => {
  try {
    const clubRepository = getRepository(Club);
    const clubs = await clubRepository.find();
    res.json(clubs);
  } catch (error) {
    res.status(500).json({ error: 'Failed to fetch clubs' });
  }
};

export const joinClub = async (req: Request, res: Response) => {
  try {
    const { clubId } = req.params;
    const userId = req.user?.id;
    
    if (!userId) {
      return res.status(401).json({ error: 'User not authenticated' });
    }

    const clubRepository = getRepository(Club);
    const club = await clubRepository.findOne(clubId);
    
    if (!club) {
      return res.status(404).json({ error: 'Club not found' });
    }

    // Add user to club logic here
    res.json({ message: 'Successfully joined club', club });
  } catch (error) {
    res.status(500).json({ error: 'Failed to join club' });
  }
};
