import 'reflect-metadata';
import 'dotenv/config';
import express from 'express';
import cors from 'cors';
import http from 'http';
import { createConnection } from 'typeorm';
import ormconfig from './ormconfig';
import authRoutes from './routes/auth.routes';
import animalRoutes from './routes/animal.routes';
import clubRoutes from './routes/club.routes';
import breedingRoutes from './routes/breeding.routes';
import veterinaryRoutes from './routes/veterinary.routes';
import wildernessRoutes from './routes/wilderness.routes';
import forumRoutes from './routes/forum.routes';
import chatRoutes from './routes/chat.routes';
import { socketHandler } from './realtime/socket';

async function main() {
  try {
    await createConnection(ormconfig);
    console.log('Database connected successfully');

    const app = express();
    app.use(cors({
      origin: '*',
      credentials: true
    }));
    app.use(express.json());

    // Health Check Route
    app.get('/health', (req, res) => {
      res.status(200).json({ status: 'ok', timestamp: new Date().toISOString() });
    });

    app.use('/api/auth', authRoutes);
    app.use('/api/animals', animalRoutes);
    app.use('/api/clubs', clubRoutes);
    app.use('/api/breeding', breedingRoutes);
    app.use('/api/veterinary', veterinaryRoutes);
    app.use('/api/wilderness', wildernessRoutes);
    app.use('/api/forum', forumRoutes);
    app.use('/api/chat', chatRoutes);

    // Import and use admin routes
    const adminRoutes = require('./routes/admin.routes').default;
    app.use('/api/admin', adminRoutes);

    const server = http.createServer(app);
    const io = require('socket.io')(server, {
      cors: {
        origin: '*',
        methods: ['GET', 'POST']
      }
    });

    socketHandler(io);

    server.listen(5000, '0.0.0.0', () => {
      console.log('Backend server running on port 5000');
      console.log('Health check available at: http://localhost:5000/health');
    });
  } catch (error) {
    console.error('Failed to start server:', error);
    process.exit(1);
  }
}

main();