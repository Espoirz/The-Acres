
import { Entity, PrimaryGeneratedColumn, Column, ManyToOne, CreateDateColumn } from 'typeorm';
import { User } from './User';

@Entity()
export class ChatMessage {
  @PrimaryGeneratedColumn('uuid')
  id!: string;

  @ManyToOne(() => User)
  sender!: User;

  @Column()
  content!: string;

  @Column({ default: 'global' })
  channel!: 'global' | 'club' | 'private';

  @Column({ nullable: true })
  targetId!: string; // club id or user id for private messages

  @CreateDateColumn()
  timestamp!: Date;
}
