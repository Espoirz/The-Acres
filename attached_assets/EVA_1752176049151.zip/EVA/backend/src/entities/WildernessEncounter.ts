
import { Entity, PrimaryGeneratedColumn, Column, ManyToOne, CreateDateColumn } from 'typeorm';
import { User } from './User';
import { Animal } from './Animal';
import { WildernessArea } from './WildernessArea';

@Entity()
export class WildernessEncounter {
  @PrimaryGeneratedColumn('uuid')
  id!: string;

  @ManyToOne(() => User)
  player!: User;

  @ManyToOne(() => Animal)
  animal!: Animal;

  @ManyToOne(() => WildernessArea, area => area.encounters)
  area!: WildernessArea;

  @Column()
  outcome!: 'captured' | 'escaped' | 'befriended' | 'injured';

  @Column('json')
  rewards!: {
    experience: number;
    items?: string[];
    currency?: number;
  };

  @CreateDateColumn()
  encounterDate!: Date;
}
