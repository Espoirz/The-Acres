
import { Entity, PrimaryGeneratedColumn, Column, ManyToOne, OneToMany, CreateDateColumn } from 'typeorm';
import { User } from './User';
import { Club } from './Club';

@Entity()
export class ForumPost {
  @PrimaryGeneratedColumn('uuid')
  id!: string;

  @Column()
  title!: string;

  @Column('text')
  content!: string;

  @ManyToOne(() => User)
  author!: User;

  @ManyToOne(() => Club, club => club.forumPosts)
  club!: Club;

  @OneToMany(() => ForumPost, post => post.parentPost)
  replies!: ForumPost[];

  @ManyToOne(() => ForumPost, post => post.replies)
  parentPost!: ForumPost;

  @CreateDateColumn()
  createdAt!: Date;
}
