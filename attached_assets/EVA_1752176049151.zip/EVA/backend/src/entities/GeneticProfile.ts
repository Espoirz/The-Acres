
import { Entity, PrimaryGeneratedColumn, Column } from 'typeorm';

@Entity()
export class GeneticProfile {
  @PrimaryGeneratedColumn('uuid')
  id!: string;

  @Column('json')
  traits!: {
    speed: number;
    stamina: number;
    strength: number;
    intelligence: number;
    coat_color: string;
    markings: string[];
  };

  @Column('json')
  genetics!: {
    dominant_alleles: string[];
    recessive_alleles: string[];
  };
}
