
import { Entity, PrimaryGeneratedColumn, Column, OneToMany } from 'typeorm';
import { WildernessEncounter } from './WildernessEncounter';

@Entity()
export class WildernessArea {
  @PrimaryGeneratedColumn('uuid')
  id!: string;

  @Column()
  name!: string;

  @Column()
  description!: string;

  @Column()
  difficulty!: number; // 1-10

  @Column('json')
  requirements!: {
    minLevel: number;
    requiredItems?: string[];
  };

  @OneToMany(() => WildernessEncounter, encounter => encounter.area)
  encounters!: WildernessEncounter[];
}
