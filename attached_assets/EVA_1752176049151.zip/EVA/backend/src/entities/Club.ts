
import { Entity, PrimaryGeneratedColumn, Column, ManyToMany, OneToMany } from 'typeorm';
import { User } from './User';
import { ForumPost } from './ForumPost';

@Entity()
export class Club {
  @PrimaryGeneratedColumn('uuid')
  id!: string;

  @Column()
  name!: string;

  @Column()
  description!: string;

  @Column({ default: 'public' })
  type!: 'public' | 'private';

  @ManyToMany(() => User, user => user.clubs)
  members!: User[];

  @OneToMany(() => ForumPost, post => post.club)
  forumPosts!: ForumPost[];
}
