
import { Router } from 'express';
import { authenticate } from '../middleware/auth.middleware';
import { getWildernessAreas, exploreArea } from '../controllers/wilderness.controller';

const router = Router();
router.use(authenticate);

router.get('/areas', getWildernessAreas);
router.post('/explore/:areaId', exploreArea);

export default router;
