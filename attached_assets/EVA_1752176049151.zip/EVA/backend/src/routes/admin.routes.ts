
import { Router, Request, Response } from 'express';
import { getRepository } from 'typeorm';
import { User } from '../entities/User';
import { Role } from '../entities/Role';
import bcrypt from 'bcrypt';

const router = Router();

router.post('/create-admin', async (req: Request, res: Response) => {
  try {
    const userRepo = getRepository(User);
    const roleRepo = getRepository(Role);
    
    // Check if admin already exists
    const existingAdmin = await userRepo.findOne({ where: { email: 'admin@everlastingacres.com' } });
    if (existingAdmin) {
      return res.status(400).json({ message: 'Admin already exists' });
    }

    // Create admin role if it doesn't exist
    let adminRole = await roleRepo.findOne({ where: { name: 'admin' } });
    if (!adminRole) {
      adminRole = roleRepo.create({
        name: 'admin',
        permissions: ['all']
      });
      await roleRepo.save(adminRole);
    }

    // Create admin user
    const hashedPassword = await bcrypt.hash('admin123', 10);
    const admin = userRepo.create({
      username: 'admin',
      email: 'admin@everlastingacres.com',
      password: hashedPassword,
      role: adminRole
    });

    await userRepo.save(admin);
    
    res.status(201).json({ 
      message: 'Admin user created successfully',
      credentials: {
        email: 'admin@everlastingacres.com',
        password: 'admin123'
      }
    });
  } catch (error) {
    console.error('Error creating admin:', error);
    res.status(500).json({ message: 'Failed to create admin user' });
  }
});

export default router;
