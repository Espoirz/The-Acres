
import { Router } from 'express';
import { authenticate } from '../middleware/auth.middleware';
import { sendMessage, getMessages } from '../controllers/chat.controller';

const router = Router();
router.use(authenticate);

router.post('/messages', sendMessage);
router.get('/messages', getMessages);

export default router;
