
import { Router } from 'express';
import { authenticate } from '../middleware/auth.middleware';
import { createPost, getPosts } from '../controllers/forum.controller';

const router = Router();
router.use(authenticate);

router.post('/posts', createPost);
router.get('/posts', getPosts);

export default router;
