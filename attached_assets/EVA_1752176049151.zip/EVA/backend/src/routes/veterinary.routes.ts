
import { Router } from 'express';
import { authenticate } from '../middleware/auth.middleware';
import { addVetRecord, getVetRecords, scheduleCheckup } from '../controllers/veterinary.controller';

const router = Router();
router.use(authenticate);

router.post('/records', addVetRecord);
router.get('/records/:animalId', getVetRecords);
router.post('/checkup', scheduleCheckup);

export default router;
