
import { Router } from 'express';
import { authenticate, authorize } from '../middleware/auth.middleware';
import { breedAnimals, getBreedingHistory } from '../controllers/breeding.controller';

const router = Router();
router.use(authenticate);

router.post('/breed', authorize(['BREEDER', 'CHAMPION']), breedAnimals);
router.get('/history', getBreedingHistory);

export default router;
